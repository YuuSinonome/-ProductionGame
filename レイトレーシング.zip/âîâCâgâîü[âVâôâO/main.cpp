#include <dxlib.h>
#include <cmath>
#include <vector>
#include "Geometry.h"
#include "Plane.h"
#include "Sphere.h"
#include "Color.h"

using namespace std;

const int screen_width = 640;
const int screen_height = 480;

///���C�g���[�V���O
///@param eye ���_���W
///@param sphere ���I�u�W�F�N�g(���̂��������ɂ���)
void RayTracing(const Position3& eye,const Sphere& sphere, Plane& plane) {
	DrawBox(0, 0, screen_width, screen_height, GetColor(100, 200, 150), true);
	auto light = Vector3(-1, 1, 1);
	light.Normalize();
	for (int y = 0; y < screen_height; ++y) {//�X�N���[���c����
		for (int x = 0; x < screen_width; ++x) {//�X�N���[��������
			Position3 ScreenPos(x - screen_width / 2, -y + screen_height / 2, 0);
			Vector3 ray = ScreenPos - eye;
			ray.Normalize();
			float distanse = 0.0f;
			if(sphere.IsHitRay(eye,ray,distanse))
			{
				unsigned char b = 255;
				auto N = (ray * distanse - (sphere.pos - eye));
				N.Normalize();
				auto diffuse = Clamp(Dot(light, N));
				auto rlight = ReflectVector(light, N);
				float specular = pow(Clamp(Dot(rlight, ray)), 10.0f);

				Color diffCol(255, 0, 100);
				Color spcCol(255, 255, 255);
				Color ambCol(32, 32, 32);

				diffCol *= diffuse;
				spcCol *= specular;

				Color col = diffCol + spcCol;
				col = col.Max(ambCol);

				// ����
				auto tmpRay = ReflectVector(ray, N);
				auto tmpStartPos = ray * distanse + eye;
				float t = Dot(tmpStartPos, plane.normal) - plane.offset / Dot(-tmpRay, plane.normal);
				Vector3 intersectPos = tmpStartPos + tmpRay * t;
				if (Dot(plane.normal, -tmpRay) > 0)
				{
					auto color = plane.GetCheckColorFromPos(intersectPos);
					auto r = Clamp(col.r * color.r / 255, 0, 255);
					auto g = Clamp(col.g * color.g / 255, 0, 255);
					auto b = Clamp(col.b * color.b / 255, 0, 255);

					DrawPixel(x, y, GetColor(r,g,b));
					continue;
				}

				DrawPixel(x, y, GetColor(col.r, col.g, col.b));
			}
			else
			{
				float t = Dot(eye, plane.normal) - plane.offset / Dot(-ray, plane.normal);
				Vector3 intersectPos = eye + ray * t;
				if (Dot(plane.normal, ray) < 0)
				{
					Color col = plane.GetCheckColorFromPos(intersectPos);
					
					if (sphere.IsHitRay(intersectPos, -light, distanse))
					{
						col *= 0.5;
					}
					DrawPixel(x, y, col.GetColor());
				}
			}
		}
	}
}


int main() {
	ChangeWindowMode(true);
	SetGraphMode(screen_width, screen_height, 32);
	SetMainWindowText(_T("1816017_��������"));
	DxLib_Init();

	vector<Primitive*> primitives;

	Sphere sphere(100, Position3(0, 0, -100));

	while(ProcessMessage() == 0 && CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		ClsDrawScreen();

		if (CheckHitKey(KEY_INPUT_LEFT))
		{
			sphere.pos.x -= 3;
		}
		if (CheckHitKey(KEY_INPUT_RIGHT))
		{
			sphere.pos.x += 3;
		}
		if (CheckHitKey(KEY_INPUT_UP))
		{
			sphere.pos.y += 3;
		}
		if (CheckHitKey(KEY_INPUT_DOWN))
		{
			sphere.pos.y -= 3;
		}

		RayTracing(Vector3(0, 0, 300), sphere, Plane(Vector3(0, 1, 0), -100));

		ScreenFlip();
	}

	// WaitKey();
	DxLib_End();
}
