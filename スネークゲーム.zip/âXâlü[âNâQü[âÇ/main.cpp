#include "DxLib.h"	//DxLibײ���؂��g�p����

//���ޯ��ү���ޗp��`
#ifdef _DEBUG
#define AST(){\
	CHAR ast_mes[256]; \
	wsprintf(ast_mes, "%s %d�s��\0", __FILE__, __LINE__); \
	MessageBox(0, ast_mes, "���ĕ\��", MB_OK);\
	}
#else
#define AST()
#endif	//_DEBUG

//�ް�Ӱ��
enum GMODE{
	GMODE_TITLE,
	GMODE_INIT,
	GMODE_CHAR_SEL,
	GMODE_GAME,
	GMODE_RESULT,
	GMODE_MAX,
};

enum CHAR_ID {
	CHAR_ID_MADOKA,
	CHAR_ID_SAYAKA,
	CHAR_ID_MAMI,
	CHAR_ID_KYOKO,
	CHAR_ID_HOMURA,
	CHAR_ID_QB,
	CHAR_ID_MAX,
};

enum IMAGE_TYPE {
	IMAGE_TYPE_CHAR,		//��׉摜
	IMAGE_TYPE_FACE,		//�籲��
	IMAGE_TYPE_STAND,		//�����G
	IMAGE_TYPE_MAX,
};

enum DIR {
	DIR_UP,
	DIR_RIGHT,
	DIR_DOWN,
	DIR_LEFT,
	DIR_MAX,
};

enum KEY_TBL {
	KEY_TBL_UP,
	KEY_TBL_RIGHT,
	KEY_TBL_DOWN,
	KEY_TBL_LEFT,
	KEY_TBL_SPEED,
	KEY_TBL_MAX,
};

#define KEY_TBL_DIR_MAX   (KEY_TBL_LEFT+1)

#define WIN_IMAGE_SIZE_X   450								//�����Җ���ʂ̉���
#define WIN_IMAGE_SIZE_Y  (300/CHAR_ID_MAX)					//�����Җ���ʂ̏c��
#define STAND_IMAGE_SIZE_X 500								//��ׂ̗����G�̉���
#define STAND_IMAGE_SIZE_Y 500								//��ׂ̗����G�̏c��

#define CHIP_CNT_X  23										//�ްщ�ʂ̉�Ͻ
#define CHIP_CNT_Y  14										//�ްщ�ʂ̏cϽ
#define CHIP_SIZE_X 32										//1�ς̉�����
#define CHIP_SIZE_Y 32										//1�Ϗc����

#define SCREEN_SIZE_X       800								//��ʂ̉�����
#define SCREEN_SIZE_Y       600								//��ʂ̏c���� 
#define GAME_SCREEN_X       CHIP_SIZE_X						//�ްѴر�̵̾��
#define GAME_SCREEN_Y      (CHIP_SIZE_Y * 3)				//�ްѴر�̵̾��
#define GAME_SCREEN_SIZE_X (CHIP_CNT_X * CHIP_SIZE_X)		//�ްщ�ʂ̉�����
#define GAME_SCREEN_SIZE_Y (CHIP_CNT_Y * CHIP_SIZE_Y)		//�ްщ�ʂ̏c����

#define PLAYER_DEF_SPEED 4
#define PLAYER_MAX       2

#define ANIME_SPEED     5
#define ANIME_IMAGE_MAX 4									//��Ұ��ݺϐ�

#define BLOCK_PTN_MAX        7								//��ۯ�
#define BLOCK_CNTUP_INV      3								//��ۯ����ޱ��߂����ڰъԊu
#define BLOCK_MAX_SIZE_FLAM (BLOCK_PTN_MAX - 1) * BLOCK_CNTUP_INV

#define TITLE_IMAGE_SIZE_X 640								//����ۺނ̉�����
#define TITLE_IMAGE_SIZE_Y 300								//����ۺނ̏c����

#define START_IMAGE_SIZE_X  210
#define START_IMAGE_SIZE_Y (150/2)
#define START_PTN_MAX 2

int gamebgImage;
int bgImage;
int winnerID;										//������ID
int flamCnt;										//�o���ڰѐ�

//��ׂ̉摜�p�\����
typedef struct {
	int image[DIR_MAX][ANIME_IMAGE_MAX];			//��׉摜ID
	int faceImage;									//��摜ID
	int standImage;									//�����GID
}CHAR_IMAGE;

//���W�p�̍\����
typedef struct {
	int X;											//x���W
	int Y;											//y���W
}Pos;

//��ڲ԰�\����
typedef struct {
	Pos pos;
	int Speed;										//�ړ���߰��
	bool Flag;										//���
	int AnimCnt;									//��Ұ��ݶ���
	CHAR_ID charID;									//�I���ID
	DIR dir;										//�ړ�����
	bool selFlag;
}Player;




Player player[PLAYER_MAX];
CHAR_IMAGE charImage[CHAR_ID_MAX];

int mapData[CHIP_CNT_Y][CHIP_CNT_X];

//�ړ����̷�ؽ�
const int keyList[PLAYER_MAX][KEY_TBL_MAX] = {		//const=���������s��
	{ KEY_INPUT_W,
	 KEY_INPUT_D,
	 KEY_INPUT_S,
	 KEY_INPUT_A,
	 KEY_INPUT_LSHIFT},
	{KEY_INPUT_UP,
	 KEY_INPUT_RIGHT,
	 KEY_INPUT_DOWN,
	 KEY_INPUT_LEFT,
	 KEY_INPUT_RCONTROL},
};

int keyFlagSp;
int keyFlagSpOld;

//����p�r�̲Ұ��
GMODE gamemode;					//���݂̹ް�Ӱ��
GMODE gamemodeOld;	
int blockImage[BLOCK_PTN_MAX];	//��ۯ��摜
int winImage[CHAR_ID_MAX];		//�����Җ������摜
int startImage;
int startcount;

int titleImage;
int titleImage2;
int selbgImage;
int selImage;
int faceImage;

char keyFlag[256];
char keyFlagOld[256];


//�������ߐ錾
bool SysInit(void);
bool GameInit(void);

bool CheckHit(Pos pos);

void GameMain(void);
void GameDraw(void);
void PlayerCtl(int no);
void InitMapID(void);
void GameResult(void);
void ObjDraw(void);
void ObjAnim(void);
void GameTitle(void);

void SetMapID(Pos  pos);
void UpDataMap(void);
void StartCount(void);
void CharSel(int no);

int WINAPI WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow)
{
	if (SysInit() == false)
	{
		return -1;
	}
	
	//�ް�ٰ��
	while (ProcessMessage() == 0
		&& CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		if (gamemode != gamemodeOld)
		{
			flamCnt = 0;
			startcount = 0;
		}
		else
		{
			flamCnt++;
			startcount++;
		}
		gamemodeOld = gamemode;
		keyFlagSpOld = keyFlagSp;
		keyFlagSp = CheckHitKey(KEY_INPUT_SPACE);

		memcpy(keyFlagOld, keyFlag, sizeof(keyFlag));
		GetHitKeyStateAll(keyFlag);

		switch (gamemode)
		{
		case GMODE_TITLE:
			GameTitle();
			break;
		case GMODE_INIT:
			GameInit();
			break;
		case GMODE_CHAR_SEL:
			for (int j = 0; j < PLAYER_MAX; j++)
			{
				CharSel(j);
			}
			break;
		case GMODE_GAME:
			GameMain();
			break;
		case GMODE_RESULT:
			GameResult();
			break;
		default:
			AST();
			gamemode = GMODE_TITLE;
			break;
		}
	}
}

void GameTitle(void)
{
	if ((keyFlagSp == 1) && (keyFlagSpOld == 0))
	{
		gamemode = GMODE_INIT;
	}
	ClsDrawScreen();
	DrawGraph(0, 0, titleImage2, true);
	DrawGraph((SCREEN_SIZE_X - TITLE_IMAGE_SIZE_X) / 3, (SCREEN_SIZE_Y - TITLE_IMAGE_SIZE_Y), titleImage, true);
	if (((flamCnt / 30) % 2) == 0)
	{
		DrawString(250, 550, "�o�k�d�`�r�d�@�f�r�o�`�b�d�@�f�j�d�x", GetColor(60, 60, 200));
	}
	ScreenFlip();
}

void CharSel(int no)
{
	if (player[0].selFlag == true)
	{
		if (player[1].selFlag == true)
		{
			gamemode = GMODE_GAME;
			player[0].selFlag = false;
			player[1].selFlag = false;
		}
	}
	if (player[no].selFlag == false)
	{
		//���ړ�
		if (((keyFlag[keyList[no][KEY_TBL_LEFT]]) == 1) && (keyFlagOld[keyList[no][KEY_TBL_LEFT]]) == 0)
		{
			if (player[no].charID >= -1 && player[no].charID < CHAR_ID_MAX)
			{
				player[no].charID = (CHAR_ID)(player[no].charID - 1);
				if (player[no].charID == -1)
				{
					player[no].charID = CHAR_ID_QB;
				}
			}
		}
		//�E�ړ�
		if (((keyFlag[keyList[no][KEY_TBL_RIGHT]]) == 1) && (keyFlagOld[keyList[no][KEY_TBL_RIGHT]]) == 0)
		{
			if (player[no].charID >= 0 && player[no].charID < CHAR_ID_MAX)
			{
				player[no].charID = (CHAR_ID)(player[no].charID + 1);
				if (player[no].charID == CHAR_ID_MAX)
				{
					player[no].charID = CHAR_ID_MADOKA;
				}
			}
		}
		//����
		if ((keyFlag[keyList[no][KEY_TBL_UP]] == 1) && (keyFlagOld[keyList[no][KEY_TBL_UP]] == 0))
		{
			player[no].selFlag = true;
		}
	}
	else
	{
		//��ݾ�
		if ((keyFlag[keyList[no][KEY_TBL_DOWN]] == 1) && (keyFlagOld[keyList[no][KEY_TBL_DOWN]] == 0))
		{
			player[no].selFlag = false;
		}
	}
	ClsDrawScreen();
	DrawGraph(0, 0, selbgImage, true);
	DrawGraph(SCREEN_SIZE_X / 4, 0, selImage, true);
	if (player[0].selFlag == true)
	{
		DrawGraph(136, 0, charImage[player[0].charID].faceImage, true);
	}
	if (player[1].selFlag == true)
	{
		DrawGraph(600, 0, charImage[player[1].charID].faceImage, true);
	}
	for (int j = 0; j < PLAYER_MAX; j++)
	{
		DrawGraph(-90 + (400 * j), 90, charImage[player[j].charID].standImage, true);
	}
	
	ScreenFlip();
}

void GameResult(void)
{
	if ((keyFlagSp == 1) && (keyFlagSpOld == 0))
	{
		gamemode = GMODE_TITLE;
	}
	ClsDrawScreen();
	ObjDraw();
	if ((0 <= winnerID) && (winnerID < PLAYER_MAX))
	{
		DrawGraph(SCREEN_SIZE_X / 2 - STAND_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - STAND_IMAGE_SIZE_Y / 2, charImage[player[winnerID].charID].standImage, true);
		DrawGraph(SCREEN_SIZE_X / 2 - WIN_IMAGE_SIZE_X   / 2, SCREEN_SIZE_Y / 2 - WIN_IMAGE_SIZE_Y   / 2, winImage [player[winnerID].charID], true);
	}
	else if (winnerID == -1)
	{
		DrawGraph(SCREEN_SIZE_X / 2 - WIN_IMAGE_SIZE_X / 2, SCREEN_SIZE_Y / 2 - WIN_IMAGE_SIZE_Y / 2, winImage[CHAR_ID_QB], true);
	}
	else
	{
		//���Ȃ��͂����̎v��������Ґ��
		AST();
	}
	if (((flamCnt / 30) % 2) == 0)
	{
		DrawString(270, 20, "�o�k�d�`�r�d�@�f�r�o�`�b�d�@�f�j�d�x", GetColor(0, 0, 0));
	}
	ScreenFlip();
}

void PlayerCtl(int no)
{
	if (flamCnt > 120)
	{
		startcount = 0;
		if (no < 0 || PLAYER_MAX <= no)
		{
			AST();
			return;
		}
		if ((player[no].pos.X % CHIP_SIZE_X) == 0 && (player[no].pos.Y % CHIP_SIZE_Y) == 0)
		{
			if (CheckHit(player[no].pos) == true)
			{
				//�ǂɓ������Ă�����A�����Ԃɂ���
				player[no].Flag = false;
				return;
			}
			SetMapID(player[no].pos);
			for (int dir = 0; dir < KEY_TBL_DIR_MAX; dir++)
			{
				if (CheckHitKey(keyList[no][dir]))
				{
					player[no].dir = (DIR)dir;
				}
			}
			/*if (CheckHitKey(keyList[no][DIR_LEFT]))
			{
				player[no].dir = DIR_LEFT;
			}
			if (CheckHitKey(keyList[no][DIR_RIGHT]))
			{
				player[no].dir = DIR_RIGHT;
			}
			if (CheckHitKey(keyList[no][DIR_UP]))
			{
				player[no].dir = DIR_UP;
			}
			if (CheckHitKey(keyList[no][DIR_DOWN]))
			{
				player[no].dir = DIR_DOWN;
			}*/
		}

		if (CheckHitKey(keyList[no][KEY_TBL_SPEED]))
		{
			player[no].Speed = PLAYER_DEF_SPEED / 2;
		}
		else
		{
			if ((player[no].pos.X % 2 == 0) && (player[no].pos.Y % 2 == 0))
			{
				player[no].Speed = PLAYER_DEF_SPEED;
			}
		}

		switch (player[no].dir)
		{
		case DIR_LEFT:
			player[no].pos.X -= player[no].Speed;
			break;
		case DIR_RIGHT:
			player[no].pos.X += player[no].Speed;
			break;
		case DIR_UP:
			player[no].pos.Y -= player[no].Speed;
			break;
		case DIR_DOWN:
			player[no].pos.Y += player[no].Speed;
			break;
		default:
			AST();
			break;
		}
	}
}

void SetMapID(Pos  pos)
{
	Pos tmpPos;
	tmpPos.X = pos.X / CHIP_SIZE_X;
	tmpPos.Y = pos.Y / CHIP_SIZE_Y;
	if (0 <= tmpPos.X && (tmpPos.X < CHIP_CNT_X) && 0 <= tmpPos.Y && (tmpPos.Y < CHIP_CNT_Y))
	{
		if (mapData[tmpPos.Y][tmpPos.X] == 0)
		{
			mapData[tmpPos.Y][tmpPos.X] = 1;
		}
	}
}
//��ڲ԰�ƕǂƂ̓����蔻��
bool CheckHit(Pos pos)
{
	bool rtnFlag = false;
	Pos tmpPos = { pos.X / CHIP_SIZE_X ,pos.Y / CHIP_SIZE_Y };

	if ((0 <= tmpPos.X) && (tmpPos.X < CHIP_CNT_X) && (0 <= tmpPos.Y) && (tmpPos.Y < CHIP_CNT_Y))
	{
		if (mapData[tmpPos.Y][tmpPos.X] >= BLOCK_MAX_SIZE_FLAM)
		{
			rtnFlag = true;
		}
	}
	else
	{
		rtnFlag = true;
	}

	return rtnFlag;
}

//ϯ�ߏ����ۯ��̏�ԍX�V
void UpDataMap(void)
{
	for (int y = 0; y < CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < CHIP_CNT_X; x++)
		{
			if (mapData[y][x] > 0)
			{
				if (mapData[y][x] < BLOCK_MAX_SIZE_FLAM)
				{
					mapData[y][x]++;
				}
			}
		}
	}
}

void StartCount(void)
{
	ClsDrawScreen();
	ObjDraw();
	if (flamCnt < 60)
	{
		if (gamemode == GMODE_GAME)
		{
			DrawRectGraph(SCREEN_SIZE_X / 2 - 105, SCREEN_SIZE_Y / 2 - 37, 0, 0, 210, 75, startImage, true, false);
		}
	}
	if (startcount > 60)
	{
		if (gamemode == GMODE_GAME)
		{
			DrawRectGraph(SCREEN_SIZE_X / 2 - 105, SCREEN_SIZE_Y / 2 - 37, 0, 75, 210, 150, startImage, true, false);
		}
	}
	ScreenFlip();
}

void GameMain(void)
{
	int tmpWinnerID = -1;
	UpDataMap();
	for (int j = 0; j < PLAYER_MAX; j++)
	{
		PlayerCtl(j);
	}
	for (int j = 0; j < PLAYER_MAX; j++)
	{
		if (player[j].Flag == false)
		{
			gamemode = GMODE_RESULT;
		}
		else
		{
			tmpWinnerID = j;
		}
	}
	if (gamemode == GMODE_RESULT)
	{
		winnerID = tmpWinnerID;
	}
	GameDraw();
}

void GameDraw(void)
{
	//�`�揈��
	ClsDrawScreen();		//��ʏ���
	ObjDraw();				//��ׂ̕`��
	StartCount();
	ScreenFlip();			//����ʂ�\��ʂɏu�Ժ�߰
	ObjAnim();				//��Ұ��݂̍X�V
}


void ObjAnim(void)
{
	for (int j = 0; j < PLAYER_MAX; j++)
	{
		player[j].AnimCnt++;
	}
}

void ObjDraw(void)
{
	DrawGraph(0, 0, gamebgImage, true);
	DrawGraph(136, 0, charImage[player[0].charID].faceImage, true);
	DrawGraph(600, 0, charImage[player[1].charID].faceImage, true);
	DrawGraph(SCREEN_SIZE_X/2 - (149 / 2), 0, bgImage, true);
	for (int y = 0; y < CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < CHIP_CNT_X; x++)
		{
			if (mapData[y][x] > 0)
			{
				int tmpID = mapData[y][x] / BLOCK_CNTUP_INV;
				tmpID = (tmpID >= BLOCK_PTN_MAX ? BLOCK_PTN_MAX - 1 : tmpID);
				DrawGraph(GAME_SCREEN_X + CHIP_SIZE_X * x, GAME_SCREEN_Y + CHIP_SIZE_Y * y, blockImage[tmpID], true);
			}
		}
	}
	for (int j = 0; j < PLAYER_MAX; j++)
	{
		int tmpAnimeID = (player[j].AnimCnt / ANIME_SPEED) % ANIME_IMAGE_MAX;

		DrawGraph(GAME_SCREEN_X + player[j].pos.X,
			GAME_SCREEN_Y + player[j].pos.Y - CHIP_SIZE_Y / 3,
			charImage[player[j].charID].image[player[j].dir][tmpAnimeID], true);
	}
	
}

bool SysInit(void)
{
	const char *fileNameList[CHAR_ID_MAX][IMAGE_TYPE_MAX] = {
		{ "image/madoka.png" , "image/icon_madoka.png" , "image/madoka_st.png" },
		{ "image/sayaka.png" , "image/icon_sayaka.png" , "image/sayaka_st.png" },
		{ "image/mami.png"   , "image/icon_mami.png"   , "image/mami_st.png"   },
		{ "image/kyoko.png"  , "image/icon_kyoko.png"  , "image/kyoko_st.png"  },
		{ "image/homura.png" , "image/icon_homura.png" , "image/homura_st.png" },
		{ "image/qb.png"     , "image/icon_qb.png"     , "image/qb_st.png"     },
	};

	//------------���я���
	SetWindowText("madokasune-ku_kadai");
	//���я���
	//640x480�ޯ�65536�FӰ�ނɐݒ�
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);

	ChangeWindowMode(true);	//true:window false:�ٽ�ذ�

	if (DxLib_Init() == -1)		//DXײ���؂̏�����
	{
		//���������s
		AST();
		return false;
	}

	//�ޯ��ޯ̬�ɕ`��
	SetDrawScreen(DX_SCREEN_BACK);

	titleImage = LoadGraph("image/title.png");
	if (titleImage == -1)
	{
		AST();
		return false;
	}
	titleImage2 = LoadGraph("image/title2.png");
	if (titleImage2 == -1)
	{
		AST();
		return false;
	}

	gamebgImage = LoadGraph("image/bg.png");
	if (gamebgImage == -1)
	{
		AST();
		return false;
	}

	startImage = LoadGraph("image/start_mes.png");
	if (startImage == -1)
	{
		AST();
		return false;
	}

	selbgImage = LoadGraph("image/sel.png");
	if (selbgImage == -1)
	{
		AST();
		return false;
	}
	selImage = LoadGraph("image/char_sel.png");
	if (selImage == -1)
	{
		AST();
		return false;
	}
	bgImage = LoadGraph("image/bg2.png");
	if (bgImage == -1)
	{
		AST();
		return false;
	}

	if (LoadDivGraph("image/block.png", BLOCK_PTN_MAX, BLOCK_PTN_MAX, 1, CHIP_SIZE_X, CHIP_SIZE_Y, blockImage) == -1)
	{
		AST();
		return false;
	}
	if (LoadDivGraph("image/WIN.png", CHAR_ID_MAX, 1, CHAR_ID_MAX, WIN_IMAGE_SIZE_X, WIN_IMAGE_SIZE_Y, winImage) == -1)
	{
		AST();
		return false;
	}
	
	for (int j = 0; j < CHAR_ID_MAX; j++)
	{
		if (LoadDivGraph(fileNameList[j][IMAGE_TYPE_CHAR], DIR_MAX*ANIME_IMAGE_MAX, ANIME_IMAGE_MAX, DIR_MAX, 
			CHIP_SIZE_X, CHIP_SIZE_Y, &charImage[j].image[0][0]) == -1)
		{
			AST();
			return false;
		}
		charImage[j].faceImage = LoadGraph(fileNameList[j][IMAGE_TYPE_FACE]);
		if (charImage[j].faceImage == -1)
		{
			AST();
			return false;
		}
		charImage[j].standImage = LoadGraph(fileNameList[j][IMAGE_TYPE_STAND]);
		if (charImage[j].standImage == -1)
		{
			AST();
			return false;
		}
	}

	keyFlagSp	 = 0;
	keyFlagSpOld = 0;
	gamemode = GMODE_TITLE;
	for (int j = 0; j < 256; j++)
	{
		keyFlagOld[j] = 0;
	}
	return true;
}
bool GameInit(void)
{
	InitMapID();

	for (int j = 0; j < PLAYER_MAX; j++)
	{
		player[j].Speed   = PLAYER_DEF_SPEED;
		player[j].Flag    = true;
		player[j].AnimCnt = 0;
		player[j].selFlag = false;
	}
	player[0].pos.X = CHIP_SIZE_X * 5;
	player[0].pos.Y = CHIP_SIZE_Y * 5;
	player[1].pos.X = CHIP_SIZE_X * (CHIP_CNT_X - 5);
	player[1].pos.Y = CHIP_SIZE_Y * 5;

	player[0].dir = DIR_RIGHT;
	player[1].dir = DIR_LEFT;

	winnerID = -1;
	gamemode = GMODE_CHAR_SEL;

	return true;
}

void InitMapID(void)
{
	for (int y = 0; y < CHIP_CNT_Y; y++)
	{
		for (int x = 0; x < CHIP_CNT_X; x++)
		{
			mapData[y][x] = 0;
		}
	}
}