#pragma once

void GameDraw(void);
void SerectDraw(void);
void ButtonDraw(void);
void ClearDraw(void);
