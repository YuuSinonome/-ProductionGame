#pragma once

bool OnClickCircle(POS cirPoc, int rad);
void GetMouseDate(void);
