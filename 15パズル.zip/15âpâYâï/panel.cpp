#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "panel.h"

bool movePanel(void)
{
	if (moveID == NON_ID)
	{
		return true;
	}

	if (movePanelPos.X != moveEndPos.X)
	{
		movePanelPos.X += (movePanelPos.X > moveEndPos.X ? -moveSpeed : moveSpeed);
	}
	else if (movePanelPos.Y != moveEndPos.Y)
	{
		movePanelPos.Y += (movePanelPos.Y > moveEndPos.Y ? -moveSpeed : moveSpeed);
	}
	else
	{
		moveID = NON_ID;
		return true;
	}
	return false;
}

void swapPanel(void)
{
	if (((mouseFlag.trg[TRG_NOW] & (~mouseFlag.trg[TRG_OLD]))& MOUSE_INPUT_LEFT) != 0)
	{
		POS panel1 = { mouseFlag.pos.X / chipSize.X, mouseFlag.pos.Y / chipSize.Y };
		POS panel2 = { panel1.X - 1, panel1.Y };
		CheckMovePanel(panel1, panel2);
		panel2 = { panel1.X + 1, panel1.Y };
		CheckMovePanel(panel1, panel2);
		panel2 = { panel1.X, panel1.Y - 1 };
		CheckMovePanel(panel1, panel2);
		panel2 = { panel1.X, panel1.Y + 1 };
		CheckMovePanel(panel1, panel2);
	}
}

void CheckMovePanel(POS p1, POS p2)		//p1(�د���������),p2(�ׂ�����)�͍��W�ł͂Ȃ�Ͻ��
{
	//p1��Ͻ�ڂ��͈͊O�Ȃ�A��������������
	if ((p1.X < 0) || (divTable[divID] <= p1.X) || (p1.Y < 0) || (divTable[divID] <= p2.Y))
	{
		return;
	}
	//p2��Ͻ�ڂ��͈͊O�Ȃ�A��������������
	if ((p2.X < 0) || (divTable[divID] <= p2.X) || (p2.Y < 0) || (divTable[divID] <= p2.Y))
	{
		return;
	}
	if (pzData[p2.Y][p2.X] != blankID)
	{
		return;
	}

	moveID = pzData[p1.Y][p1.X];
	movePanelPos = { p1.X*chipSize.X,p1.Y*chipSize.Y };
	moveEndPos = { p2.X*chipSize.X,p2.Y*chipSize.Y };

	swapNum(&pzData[p1.Y][p1.X], &pzData[p2.Y][p2.X]);
}

void SufflePanel(void)
{
	mouseFlag.trg[TRG_NOW] = MOUSE_INPUT_LEFT;
	mouseFlag.trg[TRG_OLD] = 0;
	mouseFlag.pos.X = (blankID % divTable[divID]) * chipSize.X;
	mouseFlag.pos.Y = (blankID / divTable[divID]) * chipSize.Y;
	for (int j = 0; j < 10000; j++)
	{
		switch (rand() % DIR_MAX)
		{
		case DIR_LEFT:
			mouseFlag.pos.X = (mouseFlag.pos.X - chipSize.X >= 0 ? mouseFlag.pos.X - chipSize.X : mouseFlag.pos.X);
			break;
		case DIR_RIGHT:
			mouseFlag.pos.X = (mouseFlag.pos.X + chipSize.X < IMAGE_SIZE_X ? mouseFlag.pos.X + chipSize.X : mouseFlag.pos.X);
			break;
		case DIR_UP:
			mouseFlag.pos.Y = (mouseFlag.pos.Y - chipSize.Y >= 0 ? mouseFlag.pos.Y - chipSize.Y : mouseFlag.pos.Y);
			break;
		case DIR_DOWN:
			mouseFlag.pos.Y = (mouseFlag.pos.Y + chipSize.Y < IMAGE_SIZE_Y ? mouseFlag.pos.Y + chipSize.Y : mouseFlag.pos.Y);
			break;
		default:
			AST();
			break;
		}
		swapPanel();
	}
	//�^���د��̂��߂��׸ނ�ر�ɂ���
	mouseFlag.trg[TRG_NOW] = 0;
}