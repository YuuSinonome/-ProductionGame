#pragma once

bool SysInit(void);
bool GameInit(void);
bool SelectInit(void);
void freeMenData(void);
