#define EXPORT_MAIN

#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "DxLib.h"	//DxLibײ���؂��g�p����
#include "main.h"
#include "init.h"
#include "panel.h"
#include "draw.h"
#include "mouse.h"

int WINAPI WinMain(HINSTANCE hInstance,
				   HINSTANCE hPrevInstance,
				   LPSTR lpCmdLine,
				   int nCmdShow)
{
	bool exeitFlag = false;
	SysInit();
	SelectInit();
	gamemode = GMODE_TITLE;

	//�ް�ٰ��
	while (ProcessMessage() == 0
		&& CheckHitKey(KEY_INPUT_ESCAPE) == 0
		&& exeitFlag==false)
	{
		GetMouseDate();
		switch (gamemode)
		{
		case GMODE_TITLE:
			PictureSel();
			break;
		case GMODE_SELECT:
			if (GameSelect() == false)
			{
				exeitFlag = true;
			}
			break;
		case GMODE_GAME:
			GameMain();
			break;
		case GMODE_CLEAR:
			GameClear();
			break;
		default:
			AST();
			break;
		}
	}
	freeMenData();		//���I��ذ�̉��
	DxLib_End();		//DXײ���؂̏I������
	return 0;			//������۸��т̏I��
}

void DrawDivLine(void)
{
	//DrawLine(�J�n�_��x,�J�n�_��y,�I�_��x,�I�_��y�A�F);
	int lineColor = GetColor(255, 255, 255);
	for (int y = 0; y < divTable[divID] + 1; y++)
	{
		DrawLine(0, y * (IMAGE_SIZE_Y / divTable[divID]), IMAGE_SIZE_X, y * (IMAGE_SIZE_Y / divTable[divID]), lineColor);
	}
	for (int x = 0; x < divTable[divID] + 1; x++)
	{
		DrawLine(x * (IMAGE_SIZE_X / divTable[divID]), 0, x * (IMAGE_SIZE_X / divTable[divID]), IMAGE_SIZE_Y, lineColor);
	}
}

bool GameSelect(void)
{
	if (OnClickCircle(buttonPos, BUTTON_IMAGE_SIZE_X / 2) == true)
	{
		//���݂������Ă���΁A��݈ڍs������
		gamemode = GMODE_GAME;
		if (GameInit() == false)
		{
			return false;
		}
	}
	else
	{
		if (buttonFlag == BUTTON_OFF)
		{
			if ((mouseFlag.trg[TRG_NOW] & MOUSE_INPUT_LEFT) == MOUSE_INPUT_LEFT		//!=0�ł��ǂ�
				&& (mouseFlag.trg[TRG_OLD] & MOUSE_INPUT_LEFT) == 0)
			{

				//�������Ƃ��̏���
				if (divID < (sizeof(divTable) / sizeof(divTable[0])) - 1)		//���ނ𒲂ׂ�������
				{
					divID++;
				}
			}
			/*if (((mouseFlag.trg[TRG_NOW] & (~mouseFlag.trg[TRG_OLD]))& MOUSE_INPUT_LEFT) != 0)
			{
				//�������Ƃ��̏���
			}*/
			if ((mouseFlag.trg[TRG_NOW] & MOUSE_INPUT_RIGHT) == MOUSE_INPUT_RIGHT
				&& (mouseFlag.trg[TRG_OLD] & MOUSE_INPUT_RIGHT) == 0)
			{
				if (divID > 0)
				{
					divID--;
				}
			}
		}
	}

	SerectDraw();
	return true;
}

void GameMain(void)
{
	if (movePanel() == true)
	{
		swapPanel();
		if ((CheckClear() == true) && (moveID == NON_ID))
		{
			gamemode = GMODE_CLEAR;
		}
	}
	GameDraw();
}

void GameClear(void)
{
	if (OnClickCircle(buttonPos, BUTTON_IMAGE_SIZE_X / 2) == true)
	{
		SelectInit();
		gamemode = GMODE_SELECT;
	}
	ClearDraw();
}

bool CheckClear(void)
{
	//��ׯ��ر����
	for (int y = 0; y < divTable[divID]; y++)
	{
		for (int x = 0; x < divTable[divID]; x++)
		{
			if (pzData[y][x] != y * divTable[divID] + x)
			{
				return false;
			}
		}
	}
	return true;
}

void swapNum(int *num1, int *num2)		//���ڽ�n��
{
	int tmpnum;
	tmpnum = (*num1);
	(*num1) = (*num2);
	(*num2) = tmpnum;
}

void PictureSel(void)
{
		gamemode = GMODE_SELECT;
	//if (_select.selFlag == true)
	//{
	//	_select.selFlag = false;
	//}

	//if (_select.selFlag == false)
	//{
	//	if ( ((keyFlag[CheckHitKey(KEY_INPUT_LEFT)]) == 1) && ((keyFlagOld[CheckHitKey(KEY_INPUT_LEFT)]) == 0) )
	//	{
	//		if (_select.pictID >= -1 && _select.pictID < PICTURE_ID_MAX)
	//		{
	//			_select.pictID = (PICTURE_ID)(_select.pictID - 1);
	//			if (_select.pictID == -1)
	//			{
	//				_select.pictID = PICTURE_ID_5;
	//			}
	//		}
	//	}
	//	//�E�ړ�
	//	if (((keyFlag[CheckHitKey(KEY_INPUT_RIGHT)]) == 1) && ((keyFlagOld[CheckHitKey(KEY_INPUT_RIGHT)]) == 0))
	//	{
	//		if (_select.pictID >= 0 && _select.pictID < PICTURE_ID_MAX)
	//		{
	//			_select.pictID = (PICTURE_ID)(_select.pictID + 1);
	//			if (_select.pictID == PICTURE_ID_MAX)
	//			{
	//				_select.pictID = PICTURE_ID_1;
	//			}
	//		}
	//	}
	//	//����
	//	if (((keyFlag[CheckHitKey(KEY_INPUT_UP)]) == 1) && ((keyFlagOld[CheckHitKey(KEY_INPUT_UP)]) == 0))
	//	{
	//		_select.selFlag = true;
	//	}
	//}
	//ClsDrawScreen();
	//DrawGraph(0, 0, selbgImage, true);
	//DrawGraph(SCREEN_SIZE_X / 4, 0, selImage, true);

	ScreenFlip();
}