#pragma once

bool movePanel(void);
void swapPanel(void);
void CheckMovePanel(POS p1, POS p2);
void SufflePanel(void);
