#include <math.h>
#include <time.h>
#include "DxLib.h"	//DxLibײ���؂��g�p����
#include "main.h"
#include "mouse.h"

void GetMouseDate(void)
{
	//�د����擾
	mouseFlag.trg[TRG_OLD] = mouseFlag.trg[TRG_NOW];
	mouseFlag.trg[TRG_NOW] = GetMouseInput();
	//ϳ����ق̍��W
	GetMousePoint(&mouseFlag.pos.X, &mouseFlag.pos.Y);
}

bool OnClickCircle(POS cirPoc, int rad)
{
	int x_len = mouseFlag.pos.X - (cirPoc.X + rad);
	int y_len = mouseFlag.pos.Y - (cirPoc.Y + rad);

	double mouse_len = sqrt((x_len*x_len) + (y_len*y_len));

	if (((mouseFlag.trg[TRG_NOW] & (~mouseFlag.trg[TRG_OLD]))& MOUSE_INPUT_LEFT) != 0)
	{
		if (mouse_len<(double)rad)				//rad��*�Ă��ł���
		{
			buttonFlag = BUTTON_ON;
		}
		//return mouse_len < (double)rad ? true : false;
	}

	if (((mouseFlag.trg[TRG_OLD] & (~mouseFlag.trg[TRG_NOW]))& MOUSE_INPUT_LEFT) != 0)
	{
		if (mouse_len < (double)rad)
		{
			if (buttonFlag == BUTTON_ON)
			{
				buttonFlag = BUTTON_OFF;
				return true;
			}
		}
		buttonFlag = BUTTON_OFF;
	}

	//DrawFormatString(320, 0, GetColor(255, 255, 255), "%f", mouse_len);

	return false;
}