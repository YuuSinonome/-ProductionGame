#include <time.h>
#include "DxLib.h"
#include "main.h"
#include "draw.h"



//�ްђ��̕`��֐�
void GameDraw(void)
{
	//�`�揈��
	ClsDrawScreen();		//��ʏ���
	for (int y = 0; y < divTable[divID]; y++)
	{
		for (int x = 0; x < divTable[divID]; x++)
		{
			if ((pzData[y][x] != blankID) && (moveID != pzData[y][x]))
			{
				DrawRectGraph(x * (IMAGE_SIZE_X / divTable[divID]),
					y * (IMAGE_SIZE_Y / divTable[divID]),
					(pzData[y][x] % divTable[divID])*(IMAGE_SIZE_X / divTable[divID]),
					(pzData[y][x] / divTable[divID])*(IMAGE_SIZE_Y / divTable[divID]),
					IMAGE_SIZE_X / divTable[divID],
					IMAGE_SIZE_Y / divTable[divID],
					puzzleImage,
					true,
					false);
			}
		}
	}
	DrawDivLine();
	//DrawFormatString(320, 0, GetColor(255, 255, 255), "x:%d y:%d", mouseFlag.pos.X, mouseFlag.pos.Y);
	if (moveID != NON_ID)
	{
		DrawRectGraph(movePanelPos.X, movePanelPos.Y, (moveID%divTable[divID])*chipSize.X, (moveID / divTable[divID])*chipSize.Y, chipSize.X, chipSize.Y, puzzleImage, true, false);
	}

	DrawRotaGraph(SCREEN_SIZE_X - IMAGE_SIZE_X / 4, IMAGE_SIZE_Y / 4, 0.5f, 0.0f, puzzleImage, true, false);

	ScreenFlip();			//����ʂ�\��ʂɏu�Ժ�߰
}

void SerectDraw(void)
{
	ClsDrawScreen();
	DrawGraph(0, 0, puzzleImage, true);
	DrawDivLine();
	ButtonDraw();
	//DrawFormatString(320, 0, GetColor(255, 255, 255), "%d ", buttonFlag);
	DrawString(IMAGE_SIZE_X + 33, 24, "���N���b�N : �������v���X", GetColor(255, 255, 255));
	DrawString(IMAGE_SIZE_X + 33, 43, "�E�N���b�N : �������}�C�i�X", GetColor(255, 255, 255));
	DrawString(IMAGE_SIZE_X + 81, 160, "�X�^�[�g�{�^��", GetColor(255, 255, 255));
	ScreenFlip();
}

void ButtonDraw(void)
{
	DrawRectGraph(buttonPos.X, buttonPos.Y, buttonFlag*BUTTON_IMAGE_SIZE_X, 0, BUTTON_IMAGE_SIZE_X, BUTTON_IMAGE_SIZE_Y, buttonImage, true, false);
}

void ClearDraw(void)
{
	ClsDrawScreen();
	DrawGraph(0, 0, puzzleImage, true);
	DrawString(buttonPos.X - 12, buttonPos.Y - 24, "����1��v���C����", GetColor(255, 255, 255));
	DrawString(IMAGE_SIZE_X - IMAGE_SIZE_Y + (IMAGE_SIZE_X + GetDrawFormatStringWidth("Congratulation!!") / 2),
		0, "Congratulation!!", GetColor(255, 255, 255));
	ButtonDraw();
	ScreenFlip();
}