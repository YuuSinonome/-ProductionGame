#include "DxLib.h"	//DxLibײ���؂��g�p����

//���ޯ��ү���ޗp��`
#ifdef _DEBUG
#define AST(){\
	CHAR ast_mes[256]; \
	wsprintf(ast_mes, "%s %d�s��\0", __FILE__, __LINE__); \
	MessageBox(0, ast_mes, "���ĕ\��", MB_OK);\
	}
#else
#define AST()
#endif	//_DEBUG

#define SCREEN_SIZE_X 800		//��ʂ̉�����
#define SCREEN_SIZE_Y 600		//��ʂ̏c����

#define GAME_SCREEN_X	   40	//�ްщ�ʂ̕`��̾��
#define GAME_SCREEN_Y	   75	//�ްщ�ʂ̕`��̾��
#define GAME_SCREEN_SIZE_X 640	//�ްщ�ʂ̉�����
#define GAME_SCREEN_SIZE_Y 480	//�ްщ�ʂ̏c����

#define PLAYER_SIZE_X    48
#define PLAYER_SIZE_Y    48
#define PLAYER_DEF_SPEED 5
#define PLAYER_DEF_LIFE  3		//���@����̵��ײ�

#define ENEMY_COUNT_X    8		//�G�̉����т̐�
#define ENEMY_COUNT_Y    7		//�G�̏c���т̐�
#define ENEMY_DEF_SPEED  8
#define ENEMY_SIZE_X     48
#define ENEMY_SIZE_Y     32
#define ENEMY_BACK_COUNT 3		//���@�Ɠ����������̗���
#define ENEMY_WAIT_COUNT 60
#define ENEMY_START_WAIT 60

#define PSHOT_SPEED  10
#define PSHOT_SIZE_X 6
#define PSHOT_SIZE_Y 30
#define ANIME_MAX    2			//��Ұ��ݐ�

#define ESHOT_SIZE_X 16
#define ESHOT_SIZE_Y 25
#define ESHOT_SPEED  4


//enum = �񋓌^�ϐ�
enum ENEMY_ID {
	ENEMY_ID_NON,				//����(���S���)
	ENEMY_ID_01,				//�G�P
	ENEMY_ID_02,				//�G�Q
	ENEMY_ID_03,				//�G�R
	ENEMY_ID_04,				//�G�S
	ENEMY_ID_UFO,				//UFO
	ENEMY_ID_MAX
};

enum MOVE_LR {
	MOVE_LEFT,
	MOVE_RIGHT,
	MOVE_MAX
};

enum MOVE_MODE {
	MOVE_MODE_LR,
	MOVE_MODE_DOWN,
	MOVE_MODE_MAX
};

enum GMODE {
	GMODE_TITLE,
	GMODE_GAME,
	GMODE_GAMEOVER,
	GMODE_MAX,
};

//���
enum {
	SCR_PL1,	//��ڲ԰
	SCR_HIGH,	//ʲ���
	SCR_MAX,
};
enum PLAYER_ID{
	PLAYER_ID_PL,	
	PLAYER_ID_ZANKI,
	PLAYER_ID_MAX,	
};


GMODE gamemode;

int playerImage[PLAYER_ID_MAX][ANIME_MAX];
int playerPosX;
int playerPosY;
int playerSpeed;
int playerLife;
bool playerFlag;
int playerAnimCnt;		//���@�̱�Ұ��ݶ����

int pShotImage;
int pShotPosX;
int pShotPosY;
int pShotSpeed;
bool pShotFlag;

int eShotImage;
int eShotPosX[ENEMY_COUNT_Y][ENEMY_COUNT_X];
int eShotPosY[ENEMY_COUNT_Y][ENEMY_COUNT_X];
int eShotSpeed;
bool eShotFlag[ENEMY_COUNT_Y][ENEMY_COUNT_X];

int enemyImage[ENEMY_ID_MAX][ANIME_MAX];
int enemyPosX[ENEMY_COUNT_Y][ENEMY_COUNT_X];
int enemyPosY[ENEMY_COUNT_Y][ENEMY_COUNT_X];
int enemySpeed;
ENEMY_ID enemyFlag[ENEMY_COUNT_Y][ENEMY_COUNT_X];
int enemyAnimCnt[ENEMY_COUNT_Y][ENEMY_COUNT_X];
MOVE_LR moveFlagX;
MOVE_MODE moveMode;
int enemyMoveLineX;		//�G�̈ړ��s
int enemyMoveLineY;		//�G�̈ړ���

int titleImage;
int gameoverImage;
bool keyFlagSp;			//��߰�������׸�
bool keyFlagOld;

int ScrCnt[SCR_MAX];
int blinkCnt;
int enemyScr[ENEMY_ID_MAX];

int eShotTime;

//�������ߐ錾
bool SysInit(void);
bool GameInit(void);
void GameMain(void);
void PlayerCtl(void);
void ShotCtl(void);
void GrawMain(void);
void EnemyCtl(void);
void CheckHitObj(void);
void PlayerDeathProc(void);
void GameOver(void);
void GameTitle(void);
void DrawText(void);
void AdScr(ENEMY_ID id);

int WINAPI WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow)
{
	//void (*funcPtr[3])(void) = [GameTitle, GameMain, GameOver];	�֐��߲���
	if (SysInit() == false)
	{
		return -1;
	}
	GameInit();

	//�ް�ٰ��
	while (ProcessMessage() == 0
		&& CheckHitKey(KEY_INPUT_ESCAPE) == 0)
	{
		//funcPtr[gamemode]();
		keyFlagOld = keyFlagSp;
		keyFlagSp = CheckHitKey(KEY_INPUT_SPACE);
		switch (gamemode)
		{
		case GMODE_TITLE:
			GameTitle();
			break;
		case GMODE_GAME:
			GameMain();
			break;
		case GMODE_GAMEOVER:
			GameOver();
			break;
		default:
			AST();
			gamemode = GMODE_TITLE;
			break;
		}
	}
	DxLib_End();
	return 0;
}
bool SysInit(void)
{
	//------------���я���
	SetWindowText("INVADER");
	//���я���
	//640x480�ޯ�65536�FӰ�ނɐݒ�
	SetGraphMode(SCREEN_SIZE_X, SCREEN_SIZE_Y, 16);

	ChangeWindowMode(true);		//true:window false:�ٽ�ذ�

	if (DxLib_Init() == -1)		//DXײ���؂̏�����
	{
		AST();
		return -1;				//���s:-1	return_WinMain(�֐�)�𔲂���
	}



		//�ޯ��ޯ̬�ɕ`��
		SetDrawScreen(DX_SCREEN_BACK);

		//���̨���̓ǂݍ���
		//���@E
		if (LoadDivGraph("image/serval.png", PLAYER_ID_MAX*ANIME_MAX, ANIME_MAX, PLAYER_ID_MAX, PLAYER_SIZE_X, PLAYER_SIZE_Y, &playerImage[0][0]))
		{
			AST();
			return false;
		}
		//�G
		if (LoadDivGraph("image/kemo.png", ENEMY_ID_MAX*ANIME_MAX, ANIME_MAX, ENEMY_ID_MAX, ENEMY_SIZE_X, ENEMY_SIZE_Y, &enemyImage[0][0]))
		{
			AST();
			return -1;
		}
		
		//���@�̒e
		pShotImage = LoadGraph("image/pShot.png");
		if (pShotImage == -1)
		{
			AST();
			return false;
		}

		titleImage = LoadGraph("image/TitleLogo2.png");
		if (titleImage == -1)
		{
			AST();
			return false;
		}
		gameoverImage = LoadGraph("image/GameOver.png");
		if (gameoverImage == -1)
		{
			AST();
			return false;
		}
		eShotImage = LoadGraph("image/eShot.png");
		if (eShotImage == -1)
		{
			AST();
			return false;
		}

		gamemode = GMODE_TITLE;
		ScrCnt[SCR_HIGH] = 50;
		//������
		enemyScr[ENEMY_ID_NON] = 0;
		enemyScr[ENEMY_ID_01]  = 10;
		enemyScr[ENEMY_ID_02]  = 10;
		enemyScr[ENEMY_ID_03]  = 10;
		enemyScr[ENEMY_ID_04]  = 10;
		enemyScr[ENEMY_ID_UFO] = 100;
		return true;
	}
	bool GameInit(void)
	{
		//�ϐ��̏�����
		playerPosX    = GAME_SCREEN_SIZE_X / 2;					//����x���W
		playerPosY    = GAME_SCREEN_SIZE_Y - PLAYER_SIZE_Y;		//����y���W
		playerSpeed   = PLAYER_DEF_SPEED;
		playerLife    = PLAYER_DEF_LIFE;
		playerFlag	  = true;
		playerAnimCnt = 0;

		//�G�֘A
		for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				enemyPosX[y][x]	   = (ENEMY_SIZE_X * x * 13) / 10;
				enemyPosY[y][x]    = (ENEMY_SIZE_Y * y * 5) / 4;
				enemyFlag[y][x]    = (ENEMY_ID)((y % 4) + 1);		//(�^)���^����
				enemyAnimCnt[y][x] = 0;

				eShotFlag[y][x] = false;
			}
		}
		enemySpeed = ENEMY_DEF_SPEED;
		moveFlagX  = MOVE_RIGHT;
		moveMode   = MOVE_MODE_LR;

		enemyMoveLineX = (ENEMY_COUNT_X - 1) + ENEMY_START_WAIT;
		enemyMoveLineY = ENEMY_COUNT_Y - 1;

		pShotPosX  = 0;
		pShotPosY  = 0;
		pShotSpeed = PSHOT_SPEED;
		pShotFlag  = false;

		eShotSpeed = ESHOT_SPEED;

		keyFlagSp  = false;
		keyFlagOld = false;

		eShotTime  = 700;

		//���̑�
		blinkCnt   = 0;

		ScrCnt[SCR_PL1]  = 0;

		return true;

	}

void GameMain(void)
{
	PlayerCtl();
	GrawMain();
	EnemyCtl();
	CheckHitObj();
}
	
void PlayerCtl(void)
{
	int tmpPosX;
	tmpPosX = playerPosX;
	//���ړ�
	if (CheckHitKey(KEY_INPUT_RIGHT))
	{
		tmpPosX += playerSpeed;
	}
	if (CheckHitKey(KEY_INPUT_LEFT))
	{
		tmpPosX -= playerSpeed;
	}
	//�ړ����&�␳
	if (0 <= tmpPosX)
	{
		if (tmpPosX < GAME_SCREEN_SIZE_X - PLAYER_SIZE_X)
		{
			playerPosX = tmpPosX;
		}
		else
		{
			playerPosX = GAME_SCREEN_SIZE_X - PLAYER_SIZE_X - 1;
		}
	}
	else
	{
		playerPosX = 0;
	}
	ShotCtl();
}
void ShotCtl(void)
{
	if ((keyFlagSp == true) && (keyFlagOld == false))
	{
		if (pShotFlag == false)		//!pShotFlag = pShotFlag==falge�Ɠ���
		{
			pShotPosX = playerPosX + PLAYER_SIZE_X / 2 - PSHOT_SIZE_X / 2;
			pShotPosY = playerPosY;
			pShotFlag = true;
		}
	}
	if (pShotFlag == true)			//pShotFlag = pShotFlag==true�Ɠ���
	{
		pShotPosY -= pShotSpeed;
		if (pShotPosY < -PSHOT_SIZE_Y)
		{
			pShotFlag = false;
		}
	}
	for (int y = 0; y < ENEMY_COUNT_Y; y++)
	{
		for (int x = 0; x < ENEMY_COUNT_X; x++)
		{
			if (eShotFlag[y][x] == true)
			{
				eShotPosY[y][x] += eShotSpeed;
				if (eShotPosY[y][x] >= GAME_SCREEN_SIZE_Y)
				{
					eShotFlag[y][x] = false;
				}
			}
		}
	}
}

void AdScr(ENEMY_ID id)
{
	ScrCnt[SCR_PL1] += enemyScr[id];
	if (ScrCnt[SCR_PL1] > ScrCnt[SCR_HIGH])
	{
		ScrCnt[SCR_HIGH] = ScrCnt[SCR_PL1];
	}
	//ScrCnt[SCR_HIGH] = (ScrCnt[SCR_PL1] > ScrCnt[SCR_HIGH] ? ScrCnt[SCR_PL1] : ScrCnt[SCR_HIGH]);
}

void CheckHitObj(void)
{
	bool backFlag = false;
	for (int y = 0; y < ENEMY_COUNT_Y; y++)
	{
		for (int x = 0; x < ENEMY_COUNT_X; x++)
		{
			if (enemyFlag[y][x] != ENEMY_ID_NON)
			{
				if ((pShotFlag == true) || (enemyFlag[y][x] == true))
				{
					if ((pShotPosX		 < enemyPosX[y][x] + ENEMY_SIZE_X - 15)
					 && (enemyPosX[y][x] < pShotPosX	   + PSHOT_SIZE_X - 15)
					 && (pShotPosY		 < enemyPosY[y][x] + ENEMY_SIZE_Y - 13)
				   	 && (enemyPosY[y][x] < pShotPosY	   + PSHOT_SIZE_Y))
					{
						AdScr(enemyFlag[y][x]);
						enemyFlag[y][x] = ENEMY_ID_NON;
						pShotFlag = false;
					}
				}
			}
			if ((playerFlag == true) && (playerLife >= 0))
			{
				if (enemyFlag[y][x] != ENEMY_ID_NON)
				{
					//���@�ƓG�̓����蔻��
					if ((playerPosX		 < enemyPosX[y][x] + ENEMY_SIZE_X)
					 && (enemyPosX[y][x] < playerPosX	   + PLAYER_SIZE_X)
					 && (playerPosY		 < enemyPosY[y][x] + ENEMY_SIZE_Y)
					 && (enemyPosY[y][x] < playerPosY	   + PLAYER_SIZE_Y))
					{
						PlayerDeathProc();
						playerFlag = false;

						enemyFlag[y][x] = ENEMY_ID_NON;
						if (playerLife > 0)
						{
							backFlag = true;
						}
					}
				}
			}
			if (enemyFlag[y][x] != ENEMY_ID_NON)
			{
				if (eShotFlag[y][x] == true)
				{
					if ((eShotPosX[y][x] < playerPosX	   + PLAYER_SIZE_X)
					 && (playerPosX		 < eShotPosX[y][x] + ESHOT_SIZE_X)
					 && (eShotPosY[y][x] < playerPosY	   + PLAYER_SIZE_Y)
					 && (playerPosY		 < eShotPosY[y][x] + ESHOT_SIZE_Y))
					{
						eShotFlag[y][x] = false;
						PlayerDeathProc();
					}
				}
			}
		
		}
	}
	if (backFlag == true)
	{
		playerFlag = true;
		for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				if (enemyFlag[y][x] != ENEMY_ID_NON)
				{
					enemyPosY[y][x] -= (ENEMY_SIZE_Y*ENEMY_BACK_COUNT * 5) / 4;
				}
				
			}
		}
	}
}

void PlayerDeathProc(void)
{
	playerLife--;
	playerFlag = false;
	if (playerLife <= 0)
	{
		gamemode = GMODE_GAMEOVER;
	}
}

void EnemyCtl(void)
{
	if (moveMode == MOVE_MODE_LR)
	{
		//���E�ړ�����
		for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				if (enemyFlag[y][x] != ENEMY_ID_NON)
				{
					if (enemyMoveLineX == x)
					{
						if (moveFlagX == MOVE_RIGHT)
						{
							enemyPosX[y][x] += enemySpeed;
						}
						if (moveFlagX == MOVE_LEFT)
						{
							enemyPosX[y][x] -= enemySpeed;
						}
					}
				}
			}
		}
		//�[�̓G�̌���
		int tmpPosX;
		if (moveFlagX == MOVE_RIGHT)
		{
			tmpPosX = 0;
		}
		if (moveFlagX == MOVE_LEFT)
		{
			tmpPosX = GAME_SCREEN_SIZE_X;
		}
		for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				if (moveFlagX == MOVE_RIGHT)
				{
					if (enemyPosX[y][x] > tmpPosX)
					{
						tmpPosX = enemyPosX[y][x];
					}
				}
				if (moveFlagX == MOVE_LEFT)
				{
					if (enemyPosX[y][x] < tmpPosX)
					{
						tmpPosX = enemyPosX[y][x];
					}
				}
			}
		}
		//�ړ������̐؂�ւ�����
		if (moveFlagX == MOVE_RIGHT)
		{
			if (enemyMoveLineX <= -ENEMY_WAIT_COUNT)
			{
				if (tmpPosX > GAME_SCREEN_SIZE_X - ENEMY_SIZE_X)
				{
					moveFlagX	   = MOVE_LEFT;
					enemyMoveLineX = 0;
					moveMode	   = MOVE_MODE_DOWN;
				}
			}
			enemyMoveLineX--;
			if (enemyMoveLineX < -ENEMY_WAIT_COUNT)
			{
				enemyMoveLineX = ENEMY_COUNT_X - 1;
			}
		}
		if (moveFlagX == MOVE_LEFT)
		{
			if (enemyMoveLineX >= ENEMY_COUNT_X + ENEMY_WAIT_COUNT - 1)
			{
				if (tmpPosX <= 0)
				{
					enemyMoveLineX = ENEMY_COUNT_X - 1;
					moveFlagX	   = MOVE_RIGHT;
					moveMode	   = MOVE_MODE_DOWN;
				}
			}
			enemyMoveLineX++;
			if (enemyMoveLineX >= ENEMY_COUNT_X + ENEMY_WAIT_COUNT)
			{
				enemyMoveLineX = 0;
			}
		}

		for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				if (enemyFlag[y][x] != ENEMY_ID_NON)
				{
					if (GetRand(eShotTime) == 0)
					{
						if (eShotFlag[y][x] == false)
						{
							eShotPosX[y][x] = enemyPosX[y][x] + ENEMY_SIZE_X / 2 - ESHOT_SIZE_X / 2;
							eShotPosY[y][x] = enemyPosY[y][x];
							eShotFlag[y][x] = true;
						}
					}
				}
			}
		}
	}
	else
	{
		//���ړ�����
		/*for (int y = 0; y < ENEMY_COUNT_Y; y++)
		{
			if (enemyMoveLineY == y)
			{
				for (int x = 0; x < ENEMY_COUNT_X; x++)
				{
					enemyPosY[y][x] += (ENEMY_SIZE_Y * 5) / 4;
				}
			}
		}*/
		if (enemyMoveLineY >= 0 && enemyMoveLineY < ENEMY_COUNT_Y)
		{
			for (int x = 0; x < ENEMY_COUNT_X; x++)
			{
				enemyPosY[enemyMoveLineY][x] += (ENEMY_SIZE_Y * 5) / 4;
			}
		}
		enemyMoveLineY--;
		if (enemyMoveLineY < -ENEMY_WAIT_COUNT)
		{
			enemyMoveLineY = ENEMY_COUNT_Y -1;
			moveMode	   = MOVE_MODE_LR;
		}
	}
}

void GrawMain(void)
{
	//�`�揈��
	ClsDrawScreen();		//��ʏ���

							//�ްѴر��h��
	DrawBox(GAME_SCREEN_X, GAME_SCREEN_Y, GAME_SCREEN_X + GAME_SCREEN_SIZE_X, GAME_SCREEN_Y + GAME_SCREEN_SIZE_Y,
		GetColor(50, 50, 50), true);
	if (pShotFlag == true)
	{
		DrawGraph(GAME_SCREEN_X + pShotPosX, GAME_SCREEN_Y + pShotPosY, pShotImage, true);
	}
	for (int y = 0; y < ENEMY_COUNT_Y; y++)
	{
		for (int x = 0; x < ENEMY_COUNT_X; x++)
		{
			if (eShotFlag[y][x] == true)
			{
				DrawGraph(GAME_SCREEN_X + eShotPosX[y][x], GAME_SCREEN_Y + eShotPosY[y][x], eShotImage, true);
			}
			if (enemyFlag[y][x] != ENEMY_ID_NON && enemyFlag[y][x] < ENEMY_ID_MAX)
			{
				DrawGraph(GAME_SCREEN_X + enemyPosX[y][x], GAME_SCREEN_Y + enemyPosY[y][x], enemyImage[enemyFlag[y][x]][(enemyAnimCnt[y][x] / 30) % 2], true);
				enemyAnimCnt[y][x]++;
			}
		}
	}
	DrawGraph(GAME_SCREEN_X + playerPosX, GAME_SCREEN_Y + playerPosY, playerImage[PLAYER_ID_PL][(playerAnimCnt / 30) % 2], true);
	playerAnimCnt++;

	for (int j = 0; j < playerLife - 1; j++)
	{
		DrawGraph((GAME_SCREEN_X+ GAME_SCREEN_SIZE_X)+(PLAYER_SIZE_X+5)*j, (GAME_SCREEN_Y + GAME_SCREEN_SIZE_Y) - (PLAYER_SIZE_Y * 2), playerImage[PLAYER_ID_ZANKI][0], true);
	}
	DrawText();
	ScreenFlip();			//����ʂ�\��ʂɏu�Ժ�߰

}

void GameTitle(void)
{
	if ((keyFlagSp == true) && (keyFlagOld == false))
	{
		gamemode = GMODE_GAME;
	}
	ClsDrawScreen();
	DrawGraph(180, 120, titleImage, true);
	DrawText();
	ScreenFlip();
}
void GameOver(void)
{ 
	if ((keyFlagSp == true) && (keyFlagOld == false))
	{
		GameInit();
		gamemode = GMODE_TITLE;
	}
	ClsDrawScreen();
	DrawGraph(170, 200, gameoverImage, true);
	DrawText();
	ScreenFlip();
}
void DrawText(void)
{
	int drawScr;
	int drawLengh;
	int textColor = GetColor(255, 255, 255);
	
	//ʲ���
	DrawString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X, 70, "�g�h�f�g", textColor);
	DrawString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X + 17, 90, "�r�b�n�q�d", textColor);

	drawScr   = (ScrCnt[SCR_HIGH] >= 100000 ? 99999 : ScrCnt[SCR_HIGH]);
	drawLengh = GetDrawFormatStringWidth("%d", drawScr);
	DrawFormatString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X + 100 - drawLengh, 120, textColor, "%d", drawScr);

	//PL1
	DrawString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X, 170, "�P�t�o", textColor);

	drawScr   = (ScrCnt[SCR_PL1] >= 100000 ? 99999 : ScrCnt[SCR_PL1]);
	drawLengh = GetDrawFormatStringWidth("%d", drawScr);
	DrawFormatString(GAME_SCREEN_X + GAME_SCREEN_SIZE_X + 100 - drawLengh, 200, textColor, "%d", drawScr);

	if (gamemode == GMODE_TITLE)
	{
		blinkCnt++;
		if ((blinkCnt / 30) % 2 == 0)
		{
			DrawString(250, 350, "�o�k�d�`�r�d�f �r�o�`�b�d�f �j�d�x", textColor);
		}
	}
}